import { z } from "zod";

export const signUpSchema = z.object({
  fullName: z.string().trim().min(2, "Please enter your full name."),
  email: z.string().trim().email("Please enter a valid email."),
  phone: z.string().trim().optional().nullable(),
  password: z.string().min(8, "Password must be at least 8 characters."),
  accountPurpose: z.enum(["buyer", "seller", "both", "shop"]).optional().nullable(),
  // Optional shop details, only used when accountPurpose === "shop".
  shopName: z.string().trim().min(2, "Please enter a shop name.").optional().nullable(),
  shopCity: z.string().trim().optional().nullable(),
  shopType: z.enum(["general", "new_phones"]).optional().nullable(),
});

export const signInSchema = z.object({
  email: z.string().trim().email("Please enter a valid email."),
  password: z.string().min(1, "Please enter your password."),
  expectedRole: z.enum(["USER", "SHOP", "ADMIN"]).optional(),
});

export const profileUpdateSchema = z.object({
  fullName: z.string().trim().min(2, "Please enter your full name.").optional(),
  phone: z.string().trim().min(5, "Please enter a valid phone number.").optional().nullable(),
  city: z.string().trim().min(1, "City is required. ").optional().nullable(),
  bio: z.string().trim().max(500, "Bio is too long.").optional().nullable(),
  accountPurpose: z.enum(["buyer", "seller", "both", "shop"]).optional().nullable(),
  notificationPreferences: z.object({
    listings: z.boolean(),
    messages: z.boolean(),
    marketing: z.boolean(),
    verification: z.boolean(),
  }).optional(),
});

export const createListingSchema = z.object({
  brand: z.string().trim().min(1),
  model: z.string().trim().min(1),
  storage: z.string().trim().min(1),
  color: z.string().trim().optional().nullable(),
  condition: z.enum(["New", "Excellent", "Good", "Fair"]),
  // "new" = brand-new phone sold by a shop (Marketplace "New Phones"
  // category). Only SHOP accounts may create listingType "new" listings;
  // enforced in the API route, not here, since it depends on the caller.
  listingType: z.enum(["used", "new"]).default("used"),
  price: z.number().int().positive(),
  negotiable: z.boolean().default(true),
  city: z.string().trim().min(1),
  area: z.string().trim().optional().nullable(),
  description: z.string().trim().optional().nullable(),
  batteryHealth: z.number().int().min(0).max(100).optional().nullable(),
  repairHistory: z.string().trim().optional().nullable(),
  photoCount: z.number().int().min(0).max(12).default(0),
  imageUrls: z.array(z.string().max(3_000_000)).max(8).default([]),
  requestVerification: z.boolean().default(false),
});

export const updateListingSchema = z.object({
  price: z.number().int().positive().optional(),
  negotiable: z.boolean().optional(),
  condition: z.enum(["New", "Excellent", "Good", "Fair"]).optional(),
  description: z.string().trim().optional(),
  status: z.enum(["active", "pending", "sold", "draft", "paused"]).optional(),
});

export const convertToShopSchema = z.object({
  shopName: z.string().trim().min(2, "Please enter a shop name."),
  shopEmail: z.string().trim().email("Please enter a valid email.").optional().nullable(),
  city: z.string().trim().optional().nullable(),
  shopType: z.enum(["general", "new_phones"]).default("general"),
  services: z.string().trim().max(500).optional().nullable(),
});

export const createOrderSchema = z.object({
  listingId: z.string().min(1),
});

export const sendMessageSchema = z.object({
  listingId: z.string().optional().nullable(),
  sellerId: z.string().min(1),
  text: z.string().trim().min(1).max(2000),
});

export const completeVerificationSchema = z.object({
  score: z.number().min(0).max(10),
  batteryHealth: z.number().int().min(0).max(100),
  display: z.number().min(0).max(10),
  camera: z.number().min(0).max(10),
  performance: z.number().min(0).max(10),
  physicalCondition: z.number().min(0).max(10),
  testResults: z.array(z.object({ label: z.string(), status: z.enum(["pass", "fail"]) })),
});
