import { NextRequest } from "next/server";
import { jsonError, jsonOk } from "@/server/http";
import { signUpSchema } from "@/server/validation";
import { usersRepo, toPublicUser } from "@/server/repositories/users";
import { shopsRepo } from "@/server/repositories/shops";
import { getSupabaseServer, getSupabaseRedirectUrl } from "@/server/supabase";

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => null);
  const parsed = signUpSchema.safeParse(body);
  if (!parsed.success) {
    return jsonError("Invalid sign up details.", 422, parsed.error.flatten());
  }

  const { fullName, email, phone, password, accountPurpose } = parsed.data;
  const normalizedEmail = email.trim().toLowerCase();

  // Check if user already exists in public.users
  const existingUser = await usersRepo.findByEmail(normalizedEmail);
  if (existingUser) {
    return jsonError("An account with this email already exists.", 409);
  }

  const supabase = await getSupabaseServer();

  // Create user in Supabase Auth
  const { data, error } = await supabase.auth.signUp({
    email: normalizedEmail,
    password,
    options: {
      data: { full_name: fullName, phone: phone ?? null },
      emailRedirectTo: getSupabaseRedirectUrl(req.url),
    },
  });

  if (error || !data.user) {
    return jsonError(error?.message ?? "Unable to create your account.", 400);
  }

  // Create user profile in public.users using the UUID from auth.users
  const user = await usersRepo.create({
    id: data.user.id,
    email: normalizedEmail,
    fullName,
    phone: phone ?? null,
    role: accountPurpose === "shop" ? "SHOP" : "USER",
  });

  // If shop account, create shop profile
  if (accountPurpose === "shop") {
    const shopProfile = await shopsRepo.create({
      shopName: fullName,
      shopEmail: normalizedEmail,
    });
    // Link user to shop
    await usersRepo.update(user.id, { shopId: shopProfile.id });
  }

  // Return whether email verification is required
  const requiresEmailVerification = !data.session;

  return jsonOk(
    { user: toPublicUser(user), requiresEmailVerification },
    201
  );
}
