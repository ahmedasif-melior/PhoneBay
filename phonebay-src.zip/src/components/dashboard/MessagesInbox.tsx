"use client";

import * as React from "react";
import { Send, ChevronLeft, Phone } from "lucide-react";

import { Avatar } from "@/components/ui/Avatar";
import { cn } from "@/lib/utils";

type Message = {
  id: string;
  text: string;
  senderId: string;
  createdAt: string;
  read: boolean;
};

type ConversationListItem = {
  id: string;
  buyerId: string;
  sellerId: string;
  listingId?: string | null;
  otherParty: {
    id: string;
    fullName: string;
    avatarUrl?: string | null;
  } | null;
  lastMessage: Message | null;
  unreadCount: number;
};

export function MessagesInbox() {
  const [conversations, setConversations] = React.useState<
    ConversationListItem[]
  >([]);

  const [activeId, setActiveId] = React.useState<string | null>(null);

  const [draft, setDraft] = React.useState("");

  const [showThreadMobile, setShowThreadMobile] =
    React.useState(false);

  const [messages, setMessages] = React.useState<Message[]>([]);

  const [currentUserId, setCurrentUserId] =
    React.useState<string | null>(null);

  const [sending, setSending] = React.useState(false);

  /*
   * Prevent stale requests from overwriting newer state.
   */
  const conversationRequestId = React.useRef(0);
  const messageRequestId = React.useRef(0);

  /*
   * Load currently authenticated user.
   */
  React.useEffect(() => {
    let mounted = true;

    async function loadCurrentUser() {
      try {
        const response = await fetch("/api/auth/me", {
          cache: "no-store",
        });

        if (!response.ok) {
          return;
        }

        const result = await response.json();

        if (!mounted) {
          return;
        }

        setCurrentUserId(result.user?.id ?? null);
      } catch (error) {
        console.error(
          "Failed to load current user:",
          error,
        );
      }
    }

    void loadCurrentUser();

    return () => {
      mounted = false;
    };
  }, []);

  /*
   * Load conversation list.
   */
  const loadConversations = React.useCallback(async () => {
    const requestId = ++conversationRequestId.current;

    try {
      const response = await fetch("/api/conversations", {
        cache: "no-store",
      });

      if (!response.ok) {
        return;
      }

      const result = await response.json();

      const nextConversations: ConversationListItem[] =
        Array.isArray(result.conversations)
          ? result.conversations
          : [];

      /*
       * Ignore an older request if a newer request has already
       * completed.
       */
      if (
        requestId !== conversationRequestId.current
      ) {
        return;
      }

      setConversations(nextConversations);

      /*
       * Keep the current conversation selected if it still exists.
       * Otherwise select the first conversation.
       */
      setActiveId((current) => {
        if (
          current &&
          nextConversations.some(
            (conversation) =>
              conversation.id === current,
          )
        ) {
          return current;
        }

        return nextConversations[0]?.id ?? null;
      });
    } catch (error) {
      console.error(
        "Failed to load conversations:",
        error,
      );
    }
  }, []);

  /*
   * Initial conversation load + polling.
   */
  React.useEffect(() => {
    void loadConversations();

    const intervalId = window.setInterval(() => {
      void loadConversations();
    }, 5000);

    return () => {
      window.clearInterval(intervalId);
    };
  }, [loadConversations]);

  /*
   * Load messages for a conversation.
   */
  const loadMessages = React.useCallback(
    async (conversationId: string) => {
      const requestId = ++messageRequestId.current;

      try {
        const response = await fetch(
          `/api/conversations/${conversationId}/messages`,
          {
            cache: "no-store",
          },
        );

        if (!response.ok) {
          return;
        }

        const result = await response.json();

        const nextMessages: Message[] =
          Array.isArray(result.messages)
            ? result.messages
            : [];

        /*
         * Ignore stale responses.
         */
        if (
          requestId !== messageRequestId.current
        ) {
          return;
        }

        /*
         * Remove accidental duplicate IDs from the
         * server response as a final UI safeguard.
         */
        const uniqueMessages = Array.from(
          new Map(
            nextMessages.map((message) => [
              message.id,
              message,
            ]),
          ).values(),
        );

        setMessages(uniqueMessages);
      } catch (error) {
        console.error(
          "Failed to load messages:",
          error,
        );
      }
    },
    [],
  );

  /*
   * Load messages whenever the active conversation changes.
   */
  React.useEffect(() => {
    if (!activeId) {
      setMessages([]);
      return;
    }

    let mounted = true;

    async function refreshMessages() {
      try {
        const response = await fetch(
          `/api/conversations/${activeId}/messages`,
          {
            cache: "no-store",
          },
        );

        if (!response.ok) {
          return;
        }

        const result = await response.json();

        if (!mounted) {
          return;
        }

        const nextMessages: Message[] =
          Array.isArray(result.messages)
            ? result.messages
            : [];

        /*
         * Defensive deduplication.
         */
        const uniqueMessages = Array.from(
          new Map(
            nextMessages.map((message) => [
              message.id,
              message,
            ]),
          ).values(),
        );

        setMessages(uniqueMessages);
      } catch (error) {
        if (mounted) {
          console.error(
            "Failed to load messages:",
            error,
          );
        }
      }
    }

    void refreshMessages();

    const intervalId = window.setInterval(() => {
      void refreshMessages();
    }, 4000);

    return () => {
      mounted = false;
      window.clearInterval(intervalId);
    };
  }, [activeId]);

  /*
   * Currently selected conversation.
   */
  const active = React.useMemo(
    () =>
      conversations.find(
        (conversation) =>
          conversation.id === activeId,
      ) ?? null,
    [conversations, activeId],
  );

  /*
   * Send a message.
   *
   * Important:
   * We DO NOT append result.message to state here.
   * The server response from GET /messages is the single
   * source of truth. This prevents duplicate React keys
   * when polling runs at the same time.
   */
  const sendMessage = React.useCallback(async () => {
    const text = draft.trim();

    /*
     * The sending guard prevents multiple POST requests
     * from one Enter/click while the previous request is
     * still processing.
     */
    if (!text || !active || sending) {
      return;
    }

    setSending(true);

    try {
      const response = await fetch(
        `/api/conversations/${active.id}/messages`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            text,
          }),
        },
      );

      if (!response.ok) {
        const errorText =
          await response
            .text()
            .catch(() => "");

        console.error(
          "Failed to send message:",
          errorText,
        );

        return;
      }

      /*
       * Clear the input only after the server accepted
       * the message.
       */
      setDraft("");

      /*
       * Reload the authoritative message list.
       * Do NOT do:
       *
       * setMessages((prev) => [
       *   ...prev,
       *   result.message,
       * ]);
       *
       * because polling can return the same message.
       */
      await loadMessages(active.id);

      /*
       * Refresh conversation preview / last message.
       */
      await loadConversations();
    } catch (error) {
      console.error(
        "Failed to send message:",
        error,
      );
    } finally {
      setSending(false);
    }
  }, [
    active,
    draft,
    sending,
    loadMessages,
    loadConversations,
  ]);

  return (
    <div className="border border-border rounded-[var(--pb-radius-lg)] overflow-hidden h-[calc(100vh-220px)] min-h-[420px] grid lg:grid-cols-[320px_1fr]">
      {/* Conversation list */}
      <div
        className={cn(
          "border-r border-border overflow-y-auto",
          showThreadMobile &&
            "hidden lg:block",
        )}
      >
        {conversations.length === 0 && (
          <div className="p-4 text-sm text-ink-faint">
            No conversations yet.
          </div>
        )}

        {conversations.map((conversation) => (
          <button
            key={conversation.id}
            type="button"
            onClick={() => {
              setActiveId(conversation.id);
              setShowThreadMobile(true);
            }}
            className={cn(
              "w-full text-left flex items-start gap-3 px-4 py-3.5 border-b border-border transition-colors",
              activeId === conversation.id
                ? "bg-brand-tint"
                : "hover:bg-bg",
            )}
          >
            <Avatar
              name={
                conversation.otherParty
                  ?.fullName ??
                "PhoneBay User"
              }
              size="md"
            />

            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between">
                <p className="font-medium text-ink text-sm truncate">
                  {conversation.otherParty
                    ?.fullName ??
                    "PhoneBay User"}
                </p>

                <span className="text-[11px] text-ink-faint shrink-0">
                  {conversation.lastMessage
                    ? new Date(
                        conversation.lastMessage.createdAt,
                      ).toLocaleDateString()
                    : "New"}
                </span>
              </div>

              <p className="text-xs text-ink-faint truncate">
                {conversation.listingId ??
                  "General chat"}
              </p>

              <p className="text-sm text-ink-soft truncate mt-0.5">
                {conversation.lastMessage
                  ?.text ??
                  "Start a conversation"}
              </p>
            </div>

            {conversation.unreadCount > 0 && (
              <span className="h-5 w-5 rounded-full bg-brand text-white text-[11px] flex items-center justify-center shrink-0">
                {conversation.unreadCount}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Active thread */}
<div
  className={cn(
    "flex min-h-0 flex-col overflow-hidden",
    !showThreadMobile && "hidden lg:flex",
  )}
>
  {active ? (
    <>
      {/* Thread header */}
      <div className="flex shrink-0 items-center justify-between gap-3 px-4 py-3.5 border-b border-border">
        <div className="flex items-center gap-3 min-w-0">
          <button
            type="button"
            className="lg:hidden h-8 w-8 flex items-center justify-center -ml-1"
            onClick={() => setShowThreadMobile(false)}
            aria-label="Back to conversations"
          >
            <ChevronLeft className="h-5 w-5" />
          </button>

          <Avatar
            name={active.otherParty?.fullName ?? "PhoneBay User"}
            size="sm"
          />

          <div className="min-w-0">
            <p className="font-medium text-ink text-sm truncate">
              {active.otherParty?.fullName ?? "PhoneBay User"}
            </p>

            <p className="text-xs text-ink-faint truncate">
              {active.listingId
                ? `Listing ${active.listingId}`
                : "Marketplace chat"}
            </p>
          </div>
        </div>

        <button
          type="button"
          className="inline-flex shrink-0 items-center gap-1.5 rounded-full border border-border-strong bg-surface px-2.5 py-1.5 text-xs font-medium text-ink hover:bg-bg"
          aria-label="Call user"
          onClick={() => {
            window.location.href = "tel:+923000000000";
          }}
        >
          <Phone className="h-3.5 w-3.5" />
          Call
        </button>
      </div>

      {/* Scrollable messages */}
      <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain p-4">
        <div className="flex min-h-full flex-col justify-end gap-3">
          {messages.length === 0 ? (
            <div className="flex flex-1 items-center justify-center text-sm text-ink-faint">
              No messages yet.
            </div>
          ) : (
            messages.map((message) => {
              const isMine =
                currentUserId !== null &&
                message.senderId === currentUserId;

              return (
                <div
                  key={message.id}
                  className={cn(
                    "max-w-[75%] break-words rounded-[var(--pb-radius-md)] px-3.5 py-2.5 text-sm",
                    isMine
                      ? "self-end bg-brand text-white"
                      : "self-start bg-bg text-ink",
                  )}
                >
                  {message.text}

                  <p
                    className={cn(
                      "text-[10px] mt-1",
                      isMine
                        ? "text-white/60"
                        : "text-ink-faint",
                    )}
                  >
                    {new Date(
                      message.createdAt,
                    ).toLocaleTimeString([], {
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </p>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* Composer stays fixed at bottom */}
      <form
        className="flex shrink-0 items-center gap-2.5 border-t border-border bg-surface p-3.5"
        onSubmit={(event) => {
          event.preventDefault();

          if (sending) {
            return;
          }

          void sendMessage();
        }}
      >
        <input
          value={draft}
          onChange={(event) => setDraft(event.target.value)}
          placeholder={sending ? "Sending..." : "Type a message"}
          aria-label="Message"
          disabled={sending}
          autoComplete="off"
          className="h-10 min-w-0 flex-1 rounded-full border border-border-strong px-4 text-sm focus:border-brand focus:outline-none focus:ring-2 focus:ring-brand/25 disabled:opacity-60"
        />

        <button
          type="submit"
          aria-label="Send message"
          disabled={!draft.trim() || sending}
          className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-brand text-white disabled:opacity-50"
        >
          <Send className="h-4 w-4" />
        </button>
      </form>
    </>
  ) : (
    <div className="flex flex-1 items-center justify-center text-sm text-ink-faint">
      Select a conversation
    </div>
  )}
</div>
    </div>
  );
}